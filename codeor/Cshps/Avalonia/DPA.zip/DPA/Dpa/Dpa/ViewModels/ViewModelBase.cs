﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace Dpa.ViewModels;

public class ViewModelBase : ObservableObject
{
}