using CommunityToolkit.Mvvm.ComponentModel;

namespace Dpa.Library.ViewModel;

public class ViewModelBase : ObservableObject
{
    
}