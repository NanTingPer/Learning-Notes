namespace Dpa.Library.Task;

public class ErrorMessage
{
    public const string HttpRequestTimeout = "请求超时";
    public const string HttpRequestFileError = "返回文件错误";
}