using Avalonia.Controls;

namespace Dpa.Views;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }
}